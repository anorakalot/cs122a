/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 7 Exercise # 1
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
  



#include <avr/io.h>
#include <avr/interrupt.h>
//#define tasksSize 3

unsigned char tasksSize = 3;
unsigned long tasksPeriod = 1000;
//volatile unsigned char TimerFlag = 0;
typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;
Task tasks[3];
void TimerISR(){
	//TimerFlag = 1;
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


enum three_LEDS_STATES{T_START,T_INIT,LED_1,LED_2,LED_3}three_leds_state;
enum blinking_LED_STATES{B_START,B_INIT,ON,OFF}blinking_led_state;
enum combined_out_STATES{O_START,OUTPUT}combined_out_state;

unsigned char three_leds_out = 0x00 ;
unsigned char blinking_led_out = 0x00;

// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks



void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}

// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}



///*

//*/

///*
//const unsigned char tasksSize = 2;

//*/





//int three_LEDS_tick(int three_leds_state){
int three_LEDS_tick(int three_leds_state){
	switch(three_leds_state){//transitions
		case T_START:
			three_leds_state = T_INIT;
			break;
		case T_INIT:
			three_leds_state = LED_1;
			break;
		case LED_1:
			three_leds_state = LED_2;
			break;
		case LED_2:
			three_leds_state = LED_3;
			break;
		case LED_3:
			three_leds_state = LED_1;
			break;
		default:
			three_leds_state = T_INIT;
			break;
	}
	switch(three_leds_state){//outputs
		case T_START:
			break;
		case T_INIT:
			three_leds_out = 0x00;
			break;
		case LED_1:
			three_leds_out = 0x01;
			break;
		case LED_2:
			three_leds_out = 0x02;
			break;
		case LED_3:
			three_leds_out = 0x04;
			break;
	}
	return three_leds_state;
}
//int blinking_LED_tick(blinking_led_state){
int blinking_LED_tick(int blinking_led_state){	
	switch(blinking_led_state){//transitions
		case B_START:
			blinking_led_state = B_INIT;
			break;
		case B_INIT:
			blinking_led_state =  ON;
			break;
		case ON:
			blinking_led_state = OFF;
			break;
		case OFF:
			blinking_led_state = ON;
			break;
		default:
			blinking_led_state = B_INIT;
			break;
	}
	switch(blinking_led_state){//outputs
		case B_START:
			break;
		case B_INIT:
			blinking_led_out = 0x00;
			break;
		case ON:
			blinking_led_out = 0x08;
			break;
		case OFF:
			blinking_led_out = 0x00;
			break;

	}
	return blinking_led_state;
}

int combined_out_tick(int combined_out_state){
	switch(combined_out_state){
		case O_START:
			combined_out_state = OUTPUT;
			break;
		case OUTPUT:
			combined_out_state = OUTPUT;
			break;
		default:
			combined_out_state = OUTPUT;
			break;
	}
	switch(combined_out_state){
		case OUTPUT:
			PORTD = three_leds_out | blinking_led_out;
			//PORTD = (PORTD & 0x08) | three_leds_out;
			//PORTD = (PORTD & 0x07) | blinking_led_out;
			//PORTD = three_leds_out;
			//PORTD = 0xFF;
			
			break;
	}
	return combined_out_state;
}


int main(void)
{
	
	DDRD = 0xFF; PORTD = 0x00;
	DDRA = 0x00; PORTA = 0xFF;


	///*
	unsigned char x = 0;
	tasks[x].state = T_START;
	tasks[x].period = 1000;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &three_LEDS_tick;
	x++;
	tasks[x].state = B_START;
	tasks[x].period = 1000;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &blinking_LED_tick;
	x++;
	tasks[x].state = OUTPUT;
	tasks[x].period = 1000;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &combined_out_tick;
	//*/


	
	TimerSet(tasksPeriod);
	TimerOn();

	//PORTD = 0xFF;
	//three_leds_state = T_START;
    //blinking_led_state = B_START;

	/* Replace with your application code */
    while (1) 
    {
		//PORTD = 0xFF;
	//three_leds_state = three_LEDS_tick(three_leds_state);
	//blinking_led_state = blinking_LED_tick(blinking_led_state);
	
	//three_LEDS_tick();
	//blinking_LED_tick();
	//combined_out_tick();

	//while(!TimerFlag){}
	//TimerFlag = 0;
    }
}
