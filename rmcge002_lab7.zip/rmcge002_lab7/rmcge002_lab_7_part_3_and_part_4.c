/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 7 Exercise # 3 and 4
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
  

#include <avr/io.h>
#include <avr/interrupt.h>
#define tasksSize  5
//unsigned char tasksSize = 4;
unsigned long tasksPeriod = 1;
//volatile unsigned char TimerFlag = 0;
typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	//TimerFlag = 1;
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// 0.954 hz is lowest frequency possible with this function,
// based on settings in PWM_on()
// Passing in 0 as the frequency will stop the speaker from generating sound
void set_PWM(double frequency) {
	static double current_frequency; // Keeps track of the currently set frequency
	// Will only update the registers when the frequency changes, otherwise allows
	// music to play uninterrupted.
	if (frequency != current_frequency) {
		if (!frequency) { TCCR0B &= 0x08; } //stops timer/counter
		else { TCCR0B |= 0x03; } // resumes/continues timer/counter
		
		// prevents OCR3A from overflowing, using prescaler 64
		// 0.954 is smallest frequency that will not result in overflow
		if (frequency < 0.954) { OCR0A = 0xFFFF; }
		
		// prevents OCR0A from underflowing, using prescaler 64					// 31250 is largest frequency that will not result in underflow
		else if (frequency > 31250) { OCR0A = 0x0000; }
		
		// set OCR3A based on desired frequency
		else { OCR0A = (short)(8000000 / (128 * frequency)) - 1; }

		TCNT0 = 0; // resets counter
		current_frequency = frequency; // Updates the current frequency
	}
}

void PWM_on() {
	TCCR0A = (1 << COM0A0);
	// COM3A0: Toggle PB3 on compare match between counter and OCR0A
	TCCR0B = (1 << WGM02) | (1 << CS01) | (1 << CS00);
	// WGM02: When counter (TCNT0) matches OCR0A, reset counter
	// CS01 & CS30: Set a prescaler of 64
	set_PWM(0);
}

void PWM_off() {
	TCCR0A = 0x00;
	TCCR0B = 0x00;
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks



void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}

// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}



enum three_LEDS_STATES{T_START,T_INIT,LED_1,LED_2,LED_3}three_leds_state;
enum blinking_LED_STATES{B_START,B_INIT,ON,OFF}blinking_led_state;
enum combined_out_STATES{O_START,OUTPUT}combined_out_state;
enum buzzer_STATES{BUZZ_START,BUZZ_INIT,WAIT_FOR_BUTTON,ON_BUZZER,OFF_BUZZER}buzzer_state;
enum button_buzz_STATES{BUTTON_START, BUTTON_INIT,WAIT,ADD,PA0_PRESS,SUBTRACT,PA1_PRESS}button_buzz_state;

unsigned char three_leds_out = 0x00 ;
unsigned char blinking_led_out = 0x00;
unsigned char buzz_out = 0x00;

unsigned char button = 0x00;
int  buzzer_tick(int buzzer_state){
	button = ~PINA & 0x04;
	switch(buzzer_state){
		case BUZZ_START:
			buzzer_state = BUZZ_INIT;
			break;
		case BUZZ_INIT:
			buzzer_state = WAIT_FOR_BUTTON;
			break;
		case WAIT_FOR_BUTTON:
			if (button == 0x04){
				buzzer_state = ON_BUZZER;
			}
			else{
				buzzer_state = WAIT_FOR_BUTTON;
			}
			break;
		case ON_BUZZER:
			if (button == 0x04){
				buzzer_state = OFF_BUZZER;
			}
			else{
				buzzer_state = WAIT_FOR_BUTTON;
			}
			break;
		case OFF_BUZZER:
			if (button == 0x04){
				buzzer_state = ON_BUZZER;
			}
			else{
				buzzer_state = WAIT_FOR_BUTTON;
			}
			break;
		default:
			buzzer_state = BUZZ_INIT;
			break;
	}

	switch(buzzer_state){
		case BUZZ_START:
			break;
		case BUZZ_INIT:
			//buzz_out = 0x00;
			PORTD = (PORTD & 0xEF) | 0x00;
			//set_PWM(200);
			break;
		case WAIT_FOR_BUTTON:
			//buzz_out = 0x00;
			PORTD = (PORTD & 0xEF) | 0x00;
			//set_PWM(freq);
			//PWM_off();
			//set_PWM(200);
			break;
		case ON_BUZZER:
			//buzz_out = 0x10;
			PORTD = (PORTD & 0xEF) | 0x10;
			//PWM_on();
			//set_PWM(freq);
			//set_PWM(200);
			//set_PWM(200);
			//PORTD = (PORTD & 0xEF)| buzz_out;
			break;

		case OFF_BUZZER:
			//buzz_out = 0x00;
			PORTD = (PORTD & 0xEF) | 0x00;
			//PWM_on();
			//set_PWM(freq);
			//set_PWM(200);
			//set_PWM(200);
			//PORTD = (PORTD & 0xEF)| buzz_out;
			break;
	}
	return buzzer_state;
}

unsigned char pa0_button = 0x00;
unsigned char pa1_button = 0x00;

///*

///*
///*
unsigned char BUZZER_PERIOD = 2;
int button_buzz_tick(int button_buzz_state){
	pa0_button = ~PINA & 0x01;
	pa1_button = ~PINA & 0x02;

	switch(button_buzz_state){
	case BUTTON_START:
		button_buzz_state = BUTTON_INIT;
		break;
	case BUTTON_INIT:
		button_buzz_state = WAIT;
		break;
	case WAIT:
		if (pa0_button == 0x01){
			button_buzz_state = ADD;
		}
		else if (pa1_button == 0x02){
			button_buzz_state = SUBTRACT;
		}
		else{
			button_buzz_state = WAIT;
		}
		break;
	case ADD:
		button_buzz_state = PA0_PRESS;
		break;
	case SUBTRACT:
		button_buzz_state = PA1_PRESS;
		break;
	case PA0_PRESS:
		if (pa0_button == 0x01){
		button_buzz_state = PA0_PRESS;
		}
		else{
		button_buzz_state = WAIT;
		}
		break;
	case PA1_PRESS:
		if (pa1_button == 0x02){
			button_buzz_state = PA1_PRESS;
		}
		else{
			button_buzz_state = WAIT;
		}
		break;

	}
	switch(button_buzz_state){
		case BUTTON_START:
			break;
		case BUTTON_INIT:
			break;
		case WAIT:
			//PWM_off();
			break;
		case ADD:
			tasks[BUZZER_PERIOD].period += 1;
			//freq +=100;
			//set_PWM(freq);
			//set_PWM(10000);
			break;
		case SUBTRACT:
			if (tasks[BUZZER_PERIOD].period  >=1){
			tasks[BUZZER_PERIOD].period -= 1;
			}

			//freq -=100;
			//set_PWM(0);
			//set_PWM(10);
			break;
		case PA0_PRESS:
			//PWM_on();
			break;
		case PA1_PRESS:
			//PWM_on();
			break;
	}
	return button_buzz_state;
}
//*/
//int three_LEDS_tick(int three_leds_state){
int three_LEDS_tick(int three_leds_state){
	switch(three_leds_state){//transitions
		case T_START:
			three_leds_state = T_INIT;
			break;
		case T_INIT:
			three_leds_state = LED_1;
			break;
		case LED_1:
			three_leds_state = LED_2;
			break;
		case LED_2:
			three_leds_state = LED_3;
			break;
		case LED_3:
			three_leds_state = LED_1;
			break;
		default:
			three_leds_state = T_INIT;
			break;
	}
	switch(three_leds_state){//outputs
		case T_START:
			break;
		case T_INIT:
			three_leds_out = 0x00;
			break;
		case LED_1:
			three_leds_out = 0x01;
			break;
		case LED_2:
			three_leds_out = 0x02;
			break;
		case LED_3:
			three_leds_out = 0x04;
			break;
	}
	return three_leds_state;
}
//int blinking_LED_tick(blinking_led_state){
int blinking_LED_tick(int blinking_led_state){	
	switch(blinking_led_state){//transitions
		case B_START:
			blinking_led_state = B_INIT;
			break;
		case B_INIT:
			blinking_led_state =  ON;
			break;
		case ON:
			blinking_led_state = OFF;
			break;
		case OFF:
			blinking_led_state = ON;
			break;
		default:
			blinking_led_state = B_INIT;
			break;
	}
	switch(blinking_led_state){//outputs
		case B_START:
			break;
		case B_INIT:
			blinking_led_out = 0x00;
			break;
		case ON:
			blinking_led_out = 0x08;
			break;
		case OFF:
			blinking_led_out = 0x00;
			break;
	}
	return blinking_led_state;
}

int combined_out_tick(int combined_out_state){
	switch(combined_out_state){
		case O_START:
			combined_out_state = OUTPUT;
			break;
		case OUTPUT:
			combined_out_state = OUTPUT;
			break;
		default:
			combined_out_state = OUTPUT;
			break;
	}
	switch(combined_out_state){
		case OUTPUT:
			PORTD = three_leds_out | blinking_led_out;
			//PORTD = PORTD  | buzz_out;
			//PORTD = (PORTD & 0x08) | three_leds_out;
			//PORTD = (PORTD & 0x07) | blinking_led_out;
			//PORTD = three_leds_out;
			//PORTD = 0xFF;
			//PORTD = (PORTD & 0xE0) | (three_leds_out | blinking_led_out | buzz_out);
			break;
	}
	return combined_out_state;
}



int main(void)
{
	
	DDRD = 0xFF; PORTD = 0x00;
	DDRA = 0x00; PORTA = 0xFF;
	DDRB = (DDRB & 0xF7) | 0x08; PORTB = 0x00;

	///*
	//set_PWM(20);

	//set_PWM(freq);
	unsigned char x = 0;
	tasks[x].state = T_START;
	tasks[x].period = 300;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &three_LEDS_tick;
	x++;
	tasks[x].state = B_START;
	tasks[x].period = 1000;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &blinking_LED_tick;
	x++;
	tasks[x].state = BUZZ_START;
	tasks[x].period = 2;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &buzzer_tick;
	x++;
	tasks[x].state = OUTPUT;
	tasks[x].period =100;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &combined_out_tick;
	///*
	x++;
	tasks[x].state = BUTTON_START;
	tasks[x].period = 200;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &button_buzz_tick;
	//*/
	//*/


	
	TimerSet(tasksPeriod);
	TimerOn();

	//PORTD = 0xFF;
	//three_leds_state = T_START;
    //blinking_led_state = B_START;

	/* Replace with your application code */
    while (1) 
    {
	//PWM_on();
	//PORTD = 0xFF;
	//three_leds_state = three_LEDS_tick(three_leds_state);
	//blinking_led_state = blinking_LED_tick(blinking_led_state);
	
	//three_LEDS_tick();
	//blinking_LED_tick();
	//combined_out_tick();

	//while(!TimerFlag){}
	//TimerFlag = 0;
    }
}
