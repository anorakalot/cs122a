/*	Partner(s) Name & E-mail: Jacob Poole
 *	Lab Section: 021
 *	Assignment: Lab #2  Exercise #2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "usart_ATmega1284.h"

unsigned long tasksPeriod = 10;

#define tasksSize 1

typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}


void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

enum USART_STATES{START,INIT,DO_ACTION}usart_state;

unsigned char send_var = 0;
unsigned char recieve_var = 0;
unsigned char switch_var = 0;
int usart_tick(int usart_state){
	switch(usart_state){//transitions
		case START:
		usart_state = INIT;
		break;
		case INIT:
		usart_state =DO_ACTION;
		break;
		case DO_ACTION:
		usart_state = DO_ACTION;
		break;
		default:
		usart_state = START;
		break;
	}
	
	switch(usart_state){//actions
		case START:
		break;
		case INIT:
		initUSART(0);
		initUSART(1);
		break;
		case DO_ACTION:
		switch_var = (PINB & 0x01);
		if (switch_var == 1){//leader
			tasks[0].period = 1000;
			if (send_var == 0){
				send_var = 1;
			}
			else if (send_var == 1){
				send_var = 0;
			}
			if (USART_IsSendReady(1)){
				USART_Send(send_var,1);
				USART_Flush(1);
			}
			PORTA = send_var;
			PORTC = 0x01;
		}

		else if (switch_var == 0){ // follower
			tasks[0].period = 50;
			if (USART_HasReceived(0)){
				recieve_var = USART_Receive(0);
				USART_Flush(0);
			}
			PORTA =(PORTA & 0x00) | recieve_var ;
			//PORTA =recieve_var ;
			PORTC = 0x00;
		}

		break;
	}
	return usart_state;
}




int main(void)
{
	//DDRB = 0xFF; PORTB = 0x00; // PORTB set to output, outputs init 0s
	//DDRC = 0xF0; PORTC = 0x0F; // PC7..4 outputs init 0s, PC3..0 inputs init 1s
	
	DDRA = 0xFF; PORTA = 0x00;
	DDRB = 0x00; PORTB = 0xFF;
	DDRC = 0xFF; PORTC = 0x00;
	//DDRD = 0xFF; PORTD = 0x00;

	unsigned char i = 0;
	tasks[i].state = -1;
	tasks[i].period = 100;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &usart_tick;



	TimerSet(tasksPeriod);
	TimerOn();
	
    /* Replace with your application code */
    while (1) 
    {
	}
}

