/*	Partner(s) Name & E-mail: Jacob Poole
 *	Lab Section: 021
 *	Assignment: Lab # 3 Exercise # 2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "keypad.h"
#include "io.c"

unsigned long tasksPeriod = 10;

#define tasksSize 1

typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}


void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

// Master code
void SPI_MasterInit(void) {
	// Set DDRB to have MOSI, SCK, and SS as output and MISO as input
	// Set SPCR register to enable SPI, enable master, and use SCK frequency
	//   of fosc/16  (pg. 168)
	// Make sure global interrupts are enabled on SREG register (pg. 9)
	DDRB = 0xB0;
	SPCR = 0x58; 
	SREG |= 0x80;
}
void SPI_MasterTransmit(unsigned char cData) {
	// data in SPDR will be transmitted, e.g. SPDR = cData;
	// set SS low
	SPDR = cData;
	PORTB = PORTB & 0xEF;
	while(!(SPSR & (1<<SPIF))) { // wait for transmission to complete
		;
	}
	PORTB = (PORTB & 0xEF) | 0x80;
	// set SS high
}
// Servant code
void SPI_ServantInit(void) {
	// set DDRB to have MISO line as output and MOSI, SCK, and SS as input
	// set SPCR register to enable SPI and enable SPI interrupt (pg. 168)
	// make sure global interrupts are enabled on SREG register (pg. 9)
	DDRB = 0x40;
	SPCR = 0xC0;
	SREG |= 0x80;
}
unsigned char recievedData = 0;

ISR(SPI_STC_vect) { // this is enabled in with the SPCR register�s �SPI
	// Interrupt Enable�
	// SPDR contains the received data, e.g. unsigned char receivedData =
	// SPDR;
	recievedData = SPDR;
}
enum MASTER_STATES{START_MASTER,INIT_MASTER,SEND}master_state;

unsigned char curr_pattern;
unsigned char curr_speed;
unsigned char data;


int master_tick(int master_state){
	switch(master_state){//transition
		case START_MASTER:
			master_state = INIT_MASTER;
			break;
		case INIT_MASTER:
			master_state = SEND;
			break;
		case SEND:
			master_state = SEND;
			break;
		default:
			master_state = START_MASTER;
			break;
	}

	switch(master_state){//action
		case START_MASTER:
			break;
		case INIT_MASTER:
			SPI_MasterInit();
			curr_pattern = 0x10;
			curr_speed = 0x01;
			data = 0x00;
			break;
		case SEND:
			data = (data & 0x0F) | curr_pattern;
			data = (data & 0xF0) | curr_speed;

			if (GetKeypadKey() == 'A' && curr_pattern != 0x10){
				data = (data & 0x0F) | 0x10;
				curr_pattern = 0x10;
				SPI_MasterTransmit(data);
			}
			else if (GetKeypadKey() == 'B' && curr_pattern != 0x20){
				data = (data & 0x0F) | 0x20;
				curr_pattern = 0x20;
				SPI_MasterTransmit(data);
			}
			else if (GetKeypadKey() == 'C' && curr_pattern != 0x30){
				data = (data & 0x0F) | 0x30;
				curr_pattern = 0x30;
				SPI_MasterTransmit(data);
			}
			else if (GetKeypadKey() == 'D' && curr_pattern != 0x40){
				data = (data & 0x0F) | 0x30;
				curr_pattern = 0x30;
				SPI_MasterTransmit(data);
			}

			else if (GetKeypadKey() == 'D' && curr_pattern != 0x40){
				data = (data & 0x0F) | 0x30;
				curr_pattern = 0x30;
				SPI_MasterTransmit(data);
			}

			else if (GetKeypadKey() == '1' && curr_speed != 0x01){
				data = (data & 0xF0) | 0x01;
				curr_speed = 0x01;
				SPI_MasterTransmit(data);
			}

			else if (GetKeypadKey() == '2' && curr_speed != 0x02){
				data = (data & 0xF0) | 0x02;
				curr_speed = 0x02;
				SPI_MasterTransmit(data);
			}
			else if (GetKeypadKey() == '3' && curr_speed != 0x03){
				data = (data & 0xF0) | 0x03;
				curr_speed = 0x03;
				SPI_MasterTransmit(data);
			}
			else if (GetKeypadKey() == '4' && curr_speed != 0x04){
				data = (data & 0xF0) | 0x04;
				curr_speed = 0x04;
				SPI_MasterTransmit(data);
			}
			else if (GetKeypadKey() == '5' && curr_speed != 0x05){
				data = (data & 0xF0) | 0x05;
				curr_speed = 0x05;
				SPI_MasterTransmit(data);
			}

			else if (GetKeypadKey() == '6' && curr_speed != 0x06){
				data = (data & 0xF0) | 0x06;
				curr_speed = 0x06;
				SPI_MasterTransmit(data);
			}

			else{
				//nothing

			}

			break;
	}
	return master_state;
}





enum OUTPUT_1_STATES{START_OUTPUT_1,INIT_OUTPUT_1,SEND_OUTPUT_1}output_1_state;

unsigned char output_1;
//unsigned char send_var;

int output_1_tick(int output_1_state){
	switch(output_1_state){//transition
		case START_OUTPUT_1:
		output_1_state = INIT_OUTPUT_1;
		break;
		
		case INIT_OUTPUT_1:
		output_1_state = SEND_OUTPUT_1;
		break;

		case SEND_OUTPUT_1:
		output_1_state = SEND_OUTPUT_1;
		break;
		
		default:
		output_1_state = START_OUTPUT_1;
		break;
	}

	switch(output_1_state){//action
		case START_OUTPUT_1:
		break;
		case INIT_OUTPUT_1:
		output_1 = 0xF0;
		break;
		case SEND_OUTPUT_1:
		if (output_1 == 0xF0){
			output_1 = 0x0F;
		}
		else if (output_1_state == 0x0F){
			output_1 = 0xF0;
		}
		else{
			output_1 = 0xF0;
		}
		//PORTA = 0xFF;
		break;
		
	}
	return output_1_state;
}

enum OUTPUT_2_STATES{START_OUTPUT_2,INIT_OUTPUT_2,SEND_OUTPUT_2}output_2_state;

unsigned char output_2;
//unsigned char send_var;

int output_2_tick(int output_2_state){
	switch(output_2_state){//transition
		case START_OUTPUT_2:
		output_2_state = INIT_OUTPUT_2;
		break;
		
		case INIT_OUTPUT_2:
		output_2_state = SEND_OUTPUT_2;
		break;

		case SEND_OUTPUT_2:
		output_2_state = SEND_OUTPUT_2;
		break;
		
		default:
		output_2_state = START_OUTPUT_2;
		break;
	}

	switch(output_2_state){//action
		case START_OUTPUT_2:
		break;
		case INIT_OUTPUT_2:
		output_2 = 0xAA;
		break;
		case SEND_OUTPUT_2:
		if (output_2 == 0xAA){
			output_2 = 0x55;
		}
		else if (output_2_state == 0xAA){
			output_2 = 0x55;
		}
		else{
			output_2 = 0xAA;
		}
		//PORTA = 0xFF;
		break;
		
	}
	return output_2_state;
}



enum OUTPUT_3_STATES{START_OUTPUT_3,INIT_OUTPUT_3,SEND_OUTPUT_3}output_3_state;

unsigned char output_3;
char count_out_3;
unsigned char direction;
//unsigned char send_var;

int output_3_tick(int output_3_state){
	switch(output_3_state){//transition
		case START_OUTPUT_3:
		output_3_state = INIT_OUTPUT_3;
		break;
		
		case INIT_OUTPUT_3:
		output_3_state = SEND_OUTPUT_3;
		break;

		case SEND_OUTPUT_3:
		output_3_state = SEND_OUTPUT_3;
		break;
		
		default:
		output_3_state = START_OUTPUT_3;
		break;
	}

	switch(output_3_state){//action
		case START_OUTPUT_3:
		break;
		case INIT_OUTPUT_3:
		output_3 = 0;
		count_out_3 = 0;
		direction = 0;
		break;
		case SEND_OUTPUT_3:
		output_3 = count_out_3;
		
		if (direction == 0){
			count_out_3 +=1;	
		}
		else if (direction == 1){
			count_out_3 -=1;
		}

		if (count_out_3 >=0xFF){
			direction = 1;
			count_out_3 = 0xFF;
		}

		else if  (count_out_3 <=0x00){
			direction = 0;
			count_out_3 = 0x00;
		}

		//PORTA = 0xFF;
		break;
		
	}
	return output_3_state;
}

enum OUTPUT_4_STATES{START_OUTPUT_4,INIT_OUTPUT_4,SEND_OUTPUT_4}output_4_state;

unsigned char output_4;
//unsigned char send_var;

int output_4_tick(int output_4_state){
	switch(output_4_state){//transition
		case START_OUTPUT_4:
		output_4_state = INIT_OUTPUT_4;
		break;
		
		case INIT_OUTPUT_4:
		output_4_state = SEND_OUTPUT_4;
		break;

		case SEND_OUTPUT_4:
		output_4_state = SEND_OUTPUT_4;
		break;
		
		default:
		output_4_state = START_OUTPUT_4;
		break;
	}

	switch(output_4_state){//action
		case START_OUTPUT_4:
		break;
		case INIT_OUTPUT_4:
		output_4 = 0xC0;
		break;
		case SEND_OUTPUT_4:
		if (output_4 == 0xC0){
			output_4 = 0x03;
		}
		else if (output_4_state == 0x03){
			output_4 = 0xC0;
		}
		else{
			output_4 = 0xC0;
		}
		//PORTA = 0xFF;
		break;
		
	}
	return output_4_state;
}

enum SLAVE_STATES{START_SLAVE,INIT_SLAVE,RECIEVE}slave_state;

//unsigned char send_var;
unsigned char curr_data;

int slave_tick(int slave_state){
	switch(slave_state){//transition
		case START_SLAVE:
		slave_state = INIT_SLAVE;
		break;
		case INIT_SLAVE:
		slave_state = RECIEVE;
		break;
		case RECIEVE:
		slave_state = RECIEVE;
		break;
		default:
		slave_state = START_SLAVE;
		break;
	}

	switch(slave_state){//action
		case START_SLAVE:
		break;
		case INIT_SLAVE:
		SPI_ServantInit();
		//send_var = 0;
		break;
		case RECIEVE:
		if ((recievedData & 0xF0) == 0x10){
			PORTA = output_1;
		}
		else if ((recievedData & 0xF0) == 0x20){
			PORTA = output_2;
		}
		else if ((recievedData & 0xF0) == 0x30){
			PORTA = output_3;
		}
		else if ((recievedData & 0xF0) == 0x40){
			PORTA = output_4;
		}



		//PORTA = recievedData;
		//PORTA = 0xFF;
		break;
		
	}
	return slave_state;
}


int main(void)
{
	DDRA = 0xFF;
	DDRD = 0x0F;
	DDRC = 0xFF;

	/*
	unsigned char i = 0;
	tasks[i].state = START_MASTER;
	tasks[i].period = 10;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &master_tick;
	//*/
	
	///*
	unsigned char i = 0;
	tasks[i].state = START_OUTPUT_1;
	tasks[i].period = 1000;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &output_1_tick;
	

	i = 1;
	tasks[i].state = START_OUTPUT_2;
	tasks[i].period = 1000;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &output_2_tick;

	i = 2;
	tasks[i].state = START_OUTPUT_3;
	tasks[i].period = 1000;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &output_3_tick;


	i = 3;
	tasks[i].state = START_OUTPUT_4;
	tasks[i].period = 1000;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &output_4_tick;
	
	i = 4;
	tasks[i].state = START_SLAVE;
	tasks[i].period = 10;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &slave_tick;
	
	
	
	

	


	//*/


	

	TimerSet(tasksPeriod);
	TimerOn();
		

	//LCD_init();
    //LCD_DisplayString(1,"Apples ");
	/* Replace with your application code */
    while (1) 
    {
	//PORTA = 0xFF;
	}
}