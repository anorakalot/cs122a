/*	Partner(s) Name & E-mail: Jacob Poole
 *	Lab Section: 021
 *	Assignment: Lab # 4 Exercise # 2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <stdint.h> 
#include <stdlib.h> 
#include <stdio.h> 
#include <stdbool.h> 
#include <string.h> 
#include <math.h> 
#include <avr/io.h> 
#include <avr/interrupt.h> 
#include <avr/eeprom.h> 
#include <avr/portpins.h> 
#include <avr/pgmspace.h> 
 
//FreeRTOS include files 
#include "FreeRTOS.h"
#include "task.h" 
#include "croutine.h"
//#include "list.c"
//#include "timer.c"
enum LEDState {INIT,L0,L1,L2,L3,L4,L5,L6,L7} led_state;

void LEDS_Init(){
	led_state = INIT;
}

void LEDS_Tick(){
	//Actions
	switch(led_state){
		case INIT:
		PORTD = 0;
		break;
		case L0:
		PORTD = 1;
		break;
		case L1:
		PORTD = 2;
		break;
		case L2:
		PORTD = 4;
		break;
		case L3:
		PORTD = 8;
		break;
		case L4:
		PORTD = 16;
		break;
		case L5:
		PORTD = 32;
		break;
		case L6:
		PORTD = 64;
		break;
		case L7:
		PORTD = 128;
		break;
		default:
		PORTD = 0;
		break;
	}
	//Transitions
	switch(led_state){
		case INIT:
			led_state = L0;
		break;
		case L0:
			led_state = L1;
		break;
		case L1:
			led_state = L2;
		break;
		case L2:
			led_state = L3;
		break;
		case L3:
			led_state = L4;
		break;
		case L4:
			led_state = L5;
		break;
		case L5:
			led_state = L6;
		break;
		case L6:
			led_state = L7;
		break;
		case L7:
			led_state = L0;
		break;
		default:
			led_state = INIT;
		break;
	}
}

void LedSecTask()
{
	LEDS_Init();
   for(;;) 
   { 	
	LEDS_Tick();
	vTaskDelay(100); 
   } 
}


enum part_1_task {PART_1_START,PART_1_INIT,ON,OFF}part_1_state;

void part_1_Init(){
	part_1_state = PART_1_START;
}

void part_1_tick(){
	switch(part_1_state){
		case PART_1_START:
			part_1_state = PART_1_INIT;
			break;
		case PART_1_INIT:
			part_1_state = ON;
			break;
		case ON:
			part_1_state = OFF;
			break;
		case OFF:
			part_1_state = ON;
			break;
	}

	switch(part_1_state){
		case PART_1_START:
			break;
		case PART_1_INIT:
			break;
		case ON:
			PORTD = (PORTD & 0xEA) | 0x15;
			break;
		case OFF:
			PORTD = (PORTD & 0xEA);
			break;

	}


}

void part_1_task(){
	
	part_1_Init();
	for(;;){
	part_1_tick();
	vTaskDelay(1000);
	}

}


enum part_2_1_task {PART_2_1_START,PART_2_1_INIT,ON_2_1,OFF_2_1}part_2_1_state;

void part_2_1_Init(){
	part_2_1_state = PART_2_1_START;
}

void part_2_1_tick(){
	switch(part_2_1_state){
		case PART_2_1_START:
		part_2_1_state = PART_2_1_INIT;
		break;
		case PART_2_1_INIT:
		part_2_1_state = ON_2_1;
		break;
		case ON_2_1:
		part_2_1_state = OFF_2_1;
		break;
		case OFF_2_1:
		part_2_1_state = ON_2_1;
		break;
	}

	switch(part_2_1_state){
		case PART_2_1_START:
		break;
		case PART_2_1_INIT:
		break;
		case ON_2_1:
		PORTD = (PORTD & 0xFE) | 0x01;
		break;
		case OFF_2_1:
		PORTD = (PORTD & 0xFE);
		break;

	}


}

void part_2_1_task(){
	
	part_2_1_Init();
	for(;;){
		part_2_1_tick();
		vTaskDelay(500);
	}

}

////////


enum part_2_2_task {PART_2_2_START,PART_2_2_INIT,ON_2_2,OFF_2_2}part_2_2_state;

void part_2_2_Init(){
	part_2_2_state = PART_2_2_START;
}

void part_2_2_tick(){
	switch(part_2_2_state){
		case PART_2_2_START:
		part_2_2_state = PART_2_2_INIT;
		break;
		case PART_2_2_INIT:
		part_2_2_state = ON_2_2;
		break;
		case ON_2_2:
		part_2_2_state = OFF_2_2;
		break;
		case OFF_2_2:
		part_2_2_state = ON_2_2;
		break;
	}

	switch(part_2_2_state){
		case PART_2_2_START:
		break;
		case PART_2_2_INIT:
		break;
		case ON_2_2:
		PORTD = (PORTD & 0xFB) | 0x04;
		break;
		case OFF_2_2:
		PORTD = (PORTD & 0xFB);
		break;

	}


}

void part_2_2_task(){
	
	part_2_2_Init();
	for(;;){
		part_2_2_tick();
		vTaskDelay(1000);
	}

}


enum part_2_3_task {PART_2_3_START,PART_2_3_INIT,ON_2_3,OFF_2_3}part_2_3_state;

void part_2_3_Init(){
	part_2_3_state = PART_2_3_START;
}

void part_2_3_tick(){
	switch(part_2_3_state){
		case PART_2_3_START:
		part_2_3_state = PART_2_3_INIT;
		break;
		case PART_2_3_INIT:
		part_2_3_state = ON_2_3;
		break;
		case ON_2_3:
		part_2_3_state = OFF_2_3;
		break;
		case OFF_2_3:
		part_2_3_state = ON_2_3;
		break;
	}

	switch(part_2_3_state){
		case PART_2_3_START:
		break;
		case PART_2_3_INIT:
		break;
		case ON_2_3:
		PORTD = (PORTD & 0xEF) | 0x10;
		break;
		case OFF_2_3:
		PORTD = (PORTD & 0xEF);
		break;

	}


}

void part_2_3_task(){
	
	part_2_3_Init();
	for(;;){
		part_2_3_tick();
		vTaskDelay(2500);
	}

}


void StartSecPulse(unsigned portBASE_TYPE Priority)
{
	//xTaskCreate(LedSecTask, (signed portCHAR *)"LedSecTask", configMINIMAL_STACK_SIZE, NULL, Priority, NULL );
	xTaskCreate(part_1_task,(signed portCHAR *)"part_1_task",configMINIMAL_STACK_SIZE,NULL,Priority,NULL);
}	
 
void StartSecPulse_2_1(unsigned portBASE_TYPE Priority)
{
	//xTaskCreate(LedSecTask, (signed portCHAR *)"LedSecTask", configMINIMAL_STACK_SIZE, NULL, Priority, NULL );
	xTaskCreate(part_2_1_task,(signed portCHAR *)"part_2_1_task",configMINIMAL_STACK_SIZE,NULL,Priority,NULL);
}

void StartSecPulse_2_2(unsigned portBASE_TYPE Priority)
{
	//xTaskCreate(LedSecTask, (signed portCHAR *)"LedSecTask", configMINIMAL_STACK_SIZE, NULL, Priority, NULL );
	xTaskCreate(part_2_2_task,(signed portCHAR *)"part_2_2_task",configMINIMAL_STACK_SIZE,NULL,Priority,NULL);
}

void StartSecPulse_2_3(unsigned portBASE_TYPE Priority)
{
	//xTaskCreate(LedSecTask, (signed portCHAR *)"LedSecTask", configMINIMAL_STACK_SIZE, NULL, Priority, NULL );
	xTaskCreate(part_2_3_task,(signed portCHAR *)"part_2_3_task",configMINIMAL_STACK_SIZE,NULL,Priority,NULL);
}




int main(void) 
{ 
   DDRA = 0x00; PORTA=0xFF;
   DDRD = 0xFF;
   //Start Tasks  
  // StartSecPulse(1);
  StartSecPulse_2_1(1);
  StartSecPulse_2_2(1);
  StartSecPulse_2_3(1);

    //RunSchedular 
   vTaskStartScheduler(); 
 
   return 0; 
}