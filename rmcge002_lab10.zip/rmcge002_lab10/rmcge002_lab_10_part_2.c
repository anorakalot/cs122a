/*	Partner(s) Name & E-mail:
 *	Lab Section: B21
 *	Assignment: Lab # 10 Exercise # 2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "bit.h"
#include "io.c"

#define tasksSize  1
unsigned long tasksPeriod = 1;

typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}


void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}


// Returns '\0' if no key pressed, else returns char '1', '2', ... '9', 'A', ...
// If multiple keys pressed, returns leftmost-topmost one
// Keypad must be connected to port C
/* Keypad arrangement
        PC4 PC5 PC6 PC7
   col  1   2   3   4
row
PC0 1   1 | 2 | 3 | A
PC1 2   4 | 5 | 6 | B
PC2 3   7 | 8 | 9 | C
PC3 4   * | 0 | # | D
*/

unsigned char GetKeypadKey() {

	//check key in col 1
	PORTC = 0xEF; // Enable col 4 with 0, disable others with 1�s
	asm("nop"); // add a delay to allow PORTC to stabilize before checking
	if (GetBit(PINC,0)==0) { return('D'); }
	if (GetBit(PINC,1)==0) { return('#'); }
	if (GetBit(PINC,2)==0) { return('0'); }
	if (GetBit(PINC,3)==0) { return('*'); }

	// Check keys in col 2
	PORTC = 0xDF; // Enable col 5 with 0, disable others with 1�s
	asm("nop"); // add a delay to allow PORTC to stabilize before checking
	if (GetBit(PINC,0)==0) { return('C'); }
	if (GetBit(PINC,1)==0) {return('9');}
	if (GetBit(PINC,2)==0) {return('8');}
	if (GetBit(PINC,3)==0) {return('7');}

	// Check keys in col 3
	PORTC = 0xBF; // Enable col 6 with 0, disable others with 1�s
	asm("nop"); // add a delay to allow PORTC to stabilize before checking
	if (GetBit(PINC,0)==0) { return('B'); }
	if (GetBit(PINC,1)==0) { return('6'); }
	if (GetBit(PINC,2)==0) { return('5'); }
	if (GetBit(PINC,3)==0) { return('4'); }

	// Check keys in col 4
	PORTC = 0x7F;
	asm("nop");
	if (GetBit(PINC,0)==0) { return('A'); }
	if (GetBit(PINC,1)==0) { return('3'); }
	if (GetBit(PINC,2)==0) { return('2'); }
	if (GetBit(PINC,3)==0) { return('1'); }


	return('\0'); // default value

}

enum KEYPAD_STATES{KEYPAD_START,KEYPAD_INIT,WAIT_KEYPAD,OUTPUT_KEYPAD,WAIT_UNTIL_KEYPAD_OFF}keypad_state;

unsigned char x;
unsigned char is_keypad_off;
unsigned char cursor = 1;
unsigned char index_of_output;

int keypad_tick(int keypad_state){
	switch(keypad_state){//transitions
		case KEYPAD_START:
			keypad_state = KEYPAD_INIT;
			break;
		case KEYPAD_INIT:
			keypad_state = OUTPUT_KEYPAD;
			break;
		case OUTPUT_KEYPAD:
			keypad_state = OUTPUT_KEYPAD;
			//keypad_state = WAIT_UNTIL_KEYPAD_OFF;
			break;

	}
	
	switch(keypad_state){//actions
		case KEYPAD_START:
			keypad_state = KEYPAD_INIT;
			break;
		case KEYPAD_INIT:
			cursor = 1;
			LCD_init();
			LCD_ClearScreen();
			//LCD_DisplayString(1,"CONGRATULATIONS!");
			keypad_state = OUTPUT_KEYPAD;
			break;
		case OUTPUT_KEYPAD:
			PORTB = 0x04;
			if (index_of_output == 0){
				LCD_ClearScreen();
				LCD_DisplayString(1,"");
			}
			else if (index_of_output == 1){
				LCD_ClearScreen();
				LCD_DisplayString(16,"C");
			}
			else if (index_of_output == 2){
				LCD_ClearScreen();
				LCD_DisplayString(15,"CS");
			}
			else if (index_of_output == 3){
				LCD_ClearScreen();
				LCD_DisplayString(14,"CS1");
			}
			else if (index_of_output == 4){
				LCD_ClearScreen();
				LCD_DisplayString(13,"CS12");
			}
			else if (index_of_output == 5){
				LCD_ClearScreen();
				LCD_DisplayString(12,"CS120");
			}
			else if (index_of_output == 6){
				LCD_ClearScreen();
				LCD_DisplayString(11,"CS120B");
			}
			else if (index_of_output == 7){
				LCD_ClearScreen();
				LCD_DisplayString(10,"CS120B ");
			}
			else if (index_of_output == 8){
				LCD_ClearScreen();
				LCD_DisplayString(9,"CS120B i");
			}
			else if (index_of_output == 9){
				LCD_ClearScreen();
				LCD_DisplayString(8,"CS120B is");
			}
			else if (index_of_output == 10){
				LCD_ClearScreen();
				LCD_DisplayString(7,"CS120B is ");
			}
			else if (index_of_output == 11){
				LCD_ClearScreen();
				LCD_DisplayString(6,"CS120B is L");
			}
			else if (index_of_output == 12){
				LCD_ClearScreen();
				LCD_DisplayString(5,"CS120B is Le");
			}
			else if (index_of_output == 13){
				LCD_ClearScreen();
				LCD_DisplayString(4,"CS120B is Leg");
			}
			else if (index_of_output == 14){
				LCD_ClearScreen();
				LCD_DisplayString(3,"CS120B is Lege");
			}
			else if (index_of_output == 15){
				LCD_ClearScreen();
				LCD_DisplayString(2,"CS120B is Legen");
			}
			else if (index_of_output == 16){
				LCD_ClearScreen();
				LCD_DisplayString(1,"CS120B is Legend");
			}
			else if (index_of_output == 17){
				LCD_ClearScreen();
				LCD_DisplayString(1,"S120B is Legend ");
			}
			else if (index_of_output == 18){
				LCD_ClearScreen();
				LCD_DisplayString(1,"120B is Legend w");
			}
			else if (index_of_output == 19){
				LCD_ClearScreen();
				LCD_DisplayString(1,"20B is Legend wa");
			}
			else if (index_of_output == 20){
				LCD_ClearScreen();
				LCD_DisplayString(1,"0B is Legend wai");
			}
			else if (index_of_output == 21){
				LCD_ClearScreen();
				LCD_DisplayString(1,"B is Legend wait");
			}
			else if (index_of_output == 22){
				LCD_ClearScreen();
				LCD_DisplayString(1," is Legend wait ");
			}
			else if (index_of_output == 23){
				LCD_ClearScreen();
				LCD_DisplayString(1,"is Legend wait f");
			}
			else if (index_of_output == 24){
				LCD_ClearScreen();
				LCD_DisplayString(1,"s Legend wait fo");
			}
			else if (index_of_output == 25){
				LCD_ClearScreen();
				LCD_DisplayString(1," Legend wait for");
			}
			else if (index_of_output == 26){
				LCD_ClearScreen();
				LCD_DisplayString(1,"Legend wait for ");
			}
			else if (index_of_output == 27){
				LCD_ClearScreen();
				LCD_DisplayString(1,"egend wait for i");
			}
			else if (index_of_output == 28){
				LCD_ClearScreen();
				LCD_DisplayString(1,"gend wait for it");
			}
			else if (index_of_output == 29){
				LCD_ClearScreen();
				LCD_DisplayString(1,"end wait for it");
			}
			else if (index_of_output == 30){
				LCD_ClearScreen();
				LCD_DisplayString(1,"nd wait for it D");
			}
			else if (index_of_output == 31){
				LCD_ClearScreen();
				LCD_DisplayString(1,"d wait for it DA");
			}
			else if (index_of_output == 32){
				LCD_ClearScreen();
				LCD_DisplayString(1," wait for it DAR");
			}
			else if (index_of_output == 33){
				LCD_ClearScreen();
				LCD_DisplayString(1,"wait for it DARY");
			}
			else if (index_of_output == 34){
				LCD_ClearScreen();
				LCD_DisplayString(1,"ait for it DARY");
			}
			else if (index_of_output == 35){
				LCD_ClearScreen();
				LCD_DisplayString(1,"it for it DARY");
			}
			else if (index_of_output == 36){
				LCD_ClearScreen();
				LCD_DisplayString(1,"t for it DARY");
			}
			else if (index_of_output == 37){
				LCD_ClearScreen();
				LCD_DisplayString(1," for it DARY");
			}
			else if (index_of_output == 38){
				LCD_ClearScreen();
				LCD_DisplayString(1,"for it DARY");
			}
			else if (index_of_output == 39){
				LCD_ClearScreen();
				LCD_DisplayString(1,"or it DARY");
			}
			else if (index_of_output == 40){
				LCD_ClearScreen();
				LCD_DisplayString(1,"r it DARY");
			}
			else if (index_of_output == 41){
				LCD_ClearScreen();
				LCD_DisplayString(1," it DARY");
			}
			else if (index_of_output == 42){
				LCD_ClearScreen();
				LCD_DisplayString(1,"it DARY");
			}
			else if (index_of_output == 43){
				LCD_ClearScreen();
				LCD_DisplayString(1,"t DARY");
			}
			else if (index_of_output == 44){
				LCD_ClearScreen();
				LCD_DisplayString(1," DARY");
			}
			else if (index_of_output == 45){
				LCD_ClearScreen();
				LCD_DisplayString(1,"DARY");
			}
			else if (index_of_output == 46){
				LCD_ClearScreen();
				LCD_DisplayString(1,"ARY");
			}
			else if (index_of_output == 47){
				LCD_ClearScreen();
				LCD_DisplayString(1,"RY");
			}
			else if (index_of_output == 48){
				LCD_ClearScreen();
				LCD_DisplayString(1,"Y");
			}
			else if (index_of_output == 49){
				LCD_ClearScreen();
				LCD_DisplayString(1,"");
			}
			if (index_of_output >= 49 ){
				index_of_output = 0;
			}
			index_of_output ++;

			break;			
	}

	return keypad_state;
}



int main(void)
{
	
	DDRB = 0xFF; PORTB = 0x00; // PORTB set to output, outputs init 0s
	DDRC = 0xF0; PORTC = 0x0F; // PC7..4 outputs init 0s, PC3..0 inputs init 1s
	
	DDRA = 0xF3; PORTA = 0x0C;
	DDRD = 0xFF; PORTD = 0x00;

	unsigned char i = 0;
	tasks[i].state = KEYPAD_START;
	tasks[i].period = 300;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &keypad_tick;
	/*
	i++
	tasks[i].state = 
	tasks[i].period = 100;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = & 
	*/

	TimerSet(tasksPeriod);
	TimerOn();

	while(1) {
///*
	//PORTB = 0x03;
	}	
}




			/*
			if (index_of_output == 0){
				LCD_ClearScreen();
				LCD_DisplayString(1,"");
			}
			else if (index_of_output == 1){
				LCD_ClearScreen();
				LCD_DisplayString(16,"C");
			}
			else if (index_of_output == 2){
				LCD_ClearScreen();
				LCD_DisplayString(15,"CS");
			}
			else if (index_of_output == 3){
				LCD_ClearScreen();
				LCD_DisplayString(14,"CS1");
			}
			else if (index_of_output == 4){
				LCD_ClearScreen();
				LCD_DisplayString(13,"CS12");
			}
			else if (index_of_output == 5){
				LCD_ClearScreen();
				LCD_DisplayString(12,"CS120");
			}
			else if (index_of_output == 6){
				LCD_ClearScreen();
				LCD_DisplayString(11,"CS120B");
			}
			else if (index_of_output == 7){
				LCD_ClearScreen();
				LCD_DisplayString(10,"CS120B ");
			}
			else if (index_of_output == 8){
				LCD_ClearScreen();
				LCD_DisplayString(9,"CS120B i");
			}
			else if (index_of_output == 9){
				LCD_ClearScreen();
				LCD_DisplayString(8,"CS120B is");
			}
			else if (index_of_output == 10){
				LCD_ClearScreen();
				LCD_DisplayString(7,"CS120B is ");
			}
			else if (index_of_output == 11){
				LCD_ClearScreen();
				LCD_DisplayString(6,"CS120B is L");
			}
			else if (index_of_output == 12){
				LCD_ClearScreen();
				LCD_DisplayString(5,"CS120B is Le");
			}
			else if (index_of_output == 13){
				LCD_ClearScreen();
				LCD_DisplayString(4,"CS120B is Leg");
			}
			else if (index_of_output == 14){
				LCD_ClearScreen();
				LCD_DisplayString(3,"CS120B is Lege");
			}
			else if (index_of_output == 15){
				LCD_ClearScreen();
				LCD_DisplayString(2,"CS120B is Legen");
			}
			else if (index_of_output == 16){
				LCD_ClearScreen();
				LCD_DisplayString(1,"CS120B is Legend");
			}
			else if (index_of_output == 17){
				LCD_ClearScreen();
				LCD_DisplayString(1,"S120B is Legend ");
			}
			else if (index_of_output == 18){
				LCD_ClearScreen();
				LCD_DisplayString(1,"120B is Legend w");
			}			
			else if (index_of_output == 19){
				LCD_ClearScreen();
				LCD_DisplayString(1,"20B is Legend wa");
			}
			else if (index_of_output == 20){
				LCD_ClearScreen();
				LCD_DisplayString(1,"0B is Legend wai");
			}
			else if (index_of_output == 21){
				LCD_ClearScreen();
				LCD_DisplayString(1,"B is Legend wait");
			}
			else if (index_of_output == 22){
				LCD_ClearScreen();
				LCD_DisplayString(1," is Legend wait ");
			}
			else if (index_of_output == 23){
				LCD_ClearScreen();
				LCD_DisplayString(1,"is Legend wait f");
			}
			else if (index_of_output == 24){
				LCD_ClearScreen();
				LCD_DisplayString(1,"s Legend wait fo");
			}						
			else if (index_of_output == 25){
				LCD_ClearScreen();
				LCD_DisplayString(1," Legend wait for");
			}
			else if (index_of_output == 26){
				LCD_ClearScreen();
				LCD_DisplayString(1,"Legend wait for ");
			}
			else if (index_of_output == 27){
				LCD_ClearScreen();
				LCD_DisplayString(1,"egend wait for i");
			}
			else if (index_of_output == 28){
				LCD_ClearScreen();
				LCD_DisplayString(1,"gend wait for it");
			}
			else if (index_of_output == 29){
				LCD_ClearScreen();
				LCD_DisplayString(1,"end wait for it ");
			}
			else if (index_of_output == 30){
				LCD_ClearScreen();
				LCD_DisplayString(1,"nd wait for it D");
			}
			else if (index_of_output == 31){
				LCD_ClearScreen();
				LCD_DisplayString(1,"d wait for it DA");
			}
			else if (index_of_output == 32){
				LCD_ClearScreen();
				LCD_DisplayString(1," wait for it DAR");
			}
			else if (index_of_output == 33){
				LCD_ClearScreen();
				LCD_DisplayString(1,"wait for it DARY");
			}
			else if (index_of_output == 34){
				LCD_ClearScreen();
				LCD_DisplayString(1,"ait for it DARY ");
			}
			else if (index_of_output == 35){
				LCD_ClearScreen();
				LCD_DisplayString(1,"it for it DARY ");
			}
			else if (index_of_output == 36){
				LCD_ClearScreen();
				LCD_DisplayString(1,"t for it DARY ");
			}
			else if (index_of_output == 37){
				LCD_ClearScreen();
				LCD_DisplayString(1," for it DARY ");
			}
			else if (index_of_output == 38){
				LCD_ClearScreen();
				LCD_DisplayString(1,"for it DARY ");
			}
			else if (index_of_output == 39){
				LCD_ClearScreen();
				LCD_DisplayString(1,"or it DARY ");
			}
			else if (index_of_output == 40){
				LCD_ClearScreen();
				LCD_DisplayString(1,"r it DARY ");
			}
			else if (index_of_output == 41){
				LCD_ClearScreen();
				LCD_DisplayString(1," it DARY ");
			}
			else if (index_of_output == 42){
				LCD_ClearScreen();
				LCD_DisplayString(1,"it DARY ");
			}
			else if (index_of_output == 43){
				LCD_ClearScreen();
				LCD_DisplayString(1,"t DARY ");
			}
			else if (index_of_output == 44){
				LCD_ClearScreen();
				LCD_DisplayString(1," DARY ");
			}
			else if (index_of_output == 45){
				LCD_ClearScreen();
				LCD_DisplayString(1,"DARY ");
			}
			else if (index_of_output == 46){
				LCD_ClearScreen();
				LCD_DisplayString(1,"ARY ");
			}
			else if (index_of_output == 47){
				LCD_ClearScreen();
				LCD_DisplayString(1,"RY ");
			}
			else if (index_of_output == 48){
				LCD_ClearScreen();
				LCD_DisplayString(1,"Y ");
			}
			else if (index_of_output == 49){
				LCD_ClearScreen();
				LCD_DisplayString(1," ");
			}
			else if (index_of_output == 50){
				LCD_ClearScreen();
				LCD_DisplayString(1,"");
			}

			index_of_output ++;
			//*/
