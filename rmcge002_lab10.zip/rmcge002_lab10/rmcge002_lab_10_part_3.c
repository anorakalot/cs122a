/*	Partner(s) Name & E-mail:
 *	Lab Section: B21
 *	Assignment: Lab # 10 Exercise # 3
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "bit.h"
#include "io.c"

#define tasksSize  1
unsigned long tasksPeriod = 1;

typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}


void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}


// Returns '\0' if no key pressed, else returns char '1', '2', ... '9', 'A', ...
// If multiple keys pressed, returns leftmost-topmost one
// Keypad must be connected to port C
/* Keypad arrangement
        PC4 PC5 PC6 PC7
   col  1   2   3   4
row
PC0 1   1 | 2 | 3 | A
PC1 2   4 | 5 | 6 | B
PC2 3   7 | 8 | 9 | C
PC3 4   * | 0 | # | D
*/

unsigned char GetKeypadKey() {

	//check key in col 1
	PORTC = 0xEF; // Enable col 4 with 0, disable others with 1�s
	asm("nop"); // add a delay to allow PORTC to stabilize before checking
	if (GetBit(PINC,0)==0) { return('D'); }
	if (GetBit(PINC,1)==0) { return('#'); }
	if (GetBit(PINC,2)==0) { return('0'); }
	if (GetBit(PINC,3)==0) { return('*'); }

	// Check keys in col 2
	PORTC = 0xDF; // Enable col 5 with 0, disable others with 1�s
	asm("nop"); // add a delay to allow PORTC to stabilize before checking
	if (GetBit(PINC,0)==0) { return('C'); }
	if (GetBit(PINC,1)==0) {return('9');}
	if (GetBit(PINC,2)==0) {return('8');}
	if (GetBit(PINC,3)==0) {return('7');}

	// Check keys in col 3
	PORTC = 0xBF; // Enable col 6 with 0, disable others with 1�s
	asm("nop"); // add a delay to allow PORTC to stabilize before checking
	if (GetBit(PINC,0)==0) { return('B'); }
	if (GetBit(PINC,1)==0) { return('6'); }
	if (GetBit(PINC,2)==0) { return('5'); }
	if (GetBit(PINC,3)==0) { return('4'); }

	// Check keys in col 4
	PORTC = 0x7F;
	asm("nop");
	if (GetBit(PINC,0)==0) { return('A'); }
	if (GetBit(PINC,1)==0) { return('3'); }
	if (GetBit(PINC,2)==0) { return('2'); }
	if (GetBit(PINC,3)==0) { return('1'); }


	return('\0'); // default value

}

enum KEYPAD_STATES{KEYPAD_START,KEYPAD_INIT,WAIT_KEYPAD,OUTPUT_KEYPAD,WAIT_UNTIL_KEYPAD_OFF}keypad_state;

unsigned char x;
unsigned char is_keypad_off;

int keypad_tick(int keypad_state){
	switch(keypad_state){//transitions
		case KEYPAD_START:
			keypad_state = KEYPAD_INIT;
			break;
		case KEYPAD_INIT:
			keypad_state = WAIT_KEYPAD;
			break;
		case WAIT_KEYPAD:
			if(x == '\0'){
				keypad_state = WAIT_KEYPAD;
			} 
			else{
				keypad_state = OUTPUT_KEYPAD;
			}
			break;
		case OUTPUT_KEYPAD:
			keypad_state = WAIT_UNTIL_KEYPAD_OFF;
			break;
		case WAIT_UNTIL_KEYPAD_OFF:
			if (is_keypad_off == '\0'){
				keypad_state = WAIT_KEYPAD;
			}
			else{
				keypad_state = WAIT_UNTIL_KEYPAD_OFF;
			}
			break;
	}
	
	switch(keypad_state){//actions
		case KEYPAD_START:
			keypad_state = KEYPAD_INIT;
			break;
		case KEYPAD_INIT:
			LCD_init();
			LCD_ClearScreen();
			keypad_state = OUTPUT_KEYPAD;
			break;
		case WAIT_KEYPAD:
			x = GetKeypadKey();
			break;
		case OUTPUT_KEYPAD:

			x = GetKeypadKey();		
			if (x == '\0'){
				PORTB = 0x1F;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_DisplayString(1,"NO INPUT");
			}
			else if (x == '1'){
				PORTB = 0x01;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('1');
			}
			else if (x == '2'){
				PORTB = 0x02;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('2');
			}
			else if (x == '3'){
				PORTB = 0x03;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('3');
			}
			else if (x == '4'){
				PORTB = 0x04;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('4');
			}
			else if (x == '5'){
				PORTB = 0x05;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('5');
			}				
			else if (x == '6'){
				PORTB = 0x06;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('6');
			}
			else if (x == '7'){
				PORTB = 0x07;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('7');
			}		
			else if (x == '8'){
				PORTB = 0x08;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('8');
			}
			else if (x == '9'){
				PORTB = 0x09;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('9');
			}
			else if (x == 'A'){
				PORTB = 0x0A;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('A');
			}
			else if (x == 'B'){
				PORTB = 0x0B;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('B');
			}
			else if (x == 'C'){
				PORTB = 0x0C;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('C');
			}
			else if (x == 'D'){
				PORTB = 0x0D;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('D');
			}	
			else if (x == '*'){
				PORTB = 0x0E;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('*');
			}
			else if (x == '0'){
				PORTB = 0x00;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('0');
			}
			else if (x == '#'){
				PORTB = 0x0F;
				LCD_ClearScreen();
				LCD_Cursor(1);
				LCD_WriteData('#');
			}
			else{
				PORTB = 0x1B;
			}
			break;
		case WAIT_UNTIL_KEYPAD_OFF:
			is_keypad_off = GetKeypadKey();
			break;
			
	}

	return keypad_state;
}



int main(void)
{
	
	DDRB = 0xFF; PORTB = 0x00; // PORTB set to output, outputs init 0s
	DDRC = 0xF0; PORTC = 0x0F; // PC7..4 outputs init 0s, PC3..0 inputs init 1s
	
	DDRA = 0xFF; PORTA = 0x00;
	DDRD = 0xFF; PORTD = 0x00;

	unsigned char i = 0;
	tasks[i].state = KEYPAD_START;
	tasks[i].period = 100;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = &keypad_tick;
	/*
	i++
	tasks[i].state = 
	tasks[i].period = 100;
	tasks[i].elapsedTime = 0;
	tasks[i].TickFct = & 
	*/

	TimerSet(tasksPeriod);
	TimerOn();

	while(1) {
///*
	//PORTB = 0x03;
	}	
}

