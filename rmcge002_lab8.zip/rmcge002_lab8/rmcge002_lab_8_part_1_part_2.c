/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 8 Exercise # 1-2
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


#include <avr/io.h>
#include <avr/interrupt.h>

#define tasksSize  1
unsigned long tasksPeriod = 1;

typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

void ADC_init() {
	ADCSRA |= (1 << ADEN) | (1 << ADSC) | (1 << ADATE);
	// ADEN: setting this bit enables analog-to-digital conversion.
	// ADSC: setting this bit starts the first conversion.
	// ADATE: setting this bit enables auto-triggering. Since we are
	//        in Free Running Mode, a new conversion will trigger whenever
	//        the previous conversion completes.
}


enum ADC_OUT_STATES {ADC_START,INIT, ADC_OUTPUT} adc_out_state; 

unsigned short x;
unsigned short temp;
unsigned char B;
unsigned char D;

int adc_out_tick(int adc_out_state){
	switch(adc_out_state){//transitions
		case ADC_START:
			adc_out_state = INIT;
			break;
		case INIT:
			adc_out_state = ADC_OUTPUT;
			break;
		case ADC_OUTPUT:
			adc_out_state = ADC_OUTPUT;
			break;
		default:
			adc_out_state = ADC_START;
			break;
	}
	switch(adc_out_state){//actions
		case ADC_START:
			break;
		case INIT:
			ADC_init();
			break;
		case ADC_OUTPUT:
			x = ADC;
			B  = (char)x;
			//temp = x >> 8;
			D = (char)(x>>8);
			PORTB = B;
			PORTD = D;
			//PORTB = 0xFF;
			//PORTD = 0x00;
			break;
	}
	return adc_out_state;
}


int main(void)
{
	DDRB = 0xFF; PORTB = 0x00;
	DDRD = 0xFF; PORTD = 0x00;

    /* Replace with your application code */
    
	unsigned char x = 0;
	tasks[x].state = ADC_START;
	tasks[x].period = 2;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &adc_out_tick;

	TimerSet(tasksPeriod);
	TimerOn();
		
	

	while (1) 
    {
	//PORTB = 0xFF;
	//PORTD = 0xFF;
    }
}

