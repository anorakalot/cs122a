/*
This code was automatically generated using the Riverside-Irvine State machine Builder tool
Version 2.7 --- 10/2/2018 10:56:4 PST
*/

#include "rims.h"

/*Define user variables and functions for this state machine here.*/
unsigned char SM1_Clk;
void TimerISR() {
   SM1_Clk = 1;
}

enum SM1_States { SM1_B0_on, SM1_B1_on, SM1_init, SM1_B2_on, SM1_B3_on, SM1_B4_on, SM1_B5_on, SM1_B6_on, SM1_B7_on } SM1_State;

TickFct_State_machine_1() {
   switch(SM1_State) { // Transitions
      case -1:
         SM1_State = SM1_init;
         break;
         case SM1_B0_on: 
         if (A0 == 0) {
            SM1_State = SM1_B1_on;
            B0 = 0;
            
         }
         else if (A0 == 1) {
            SM1_State = SM1_B7_on;
            B0 = 0;
         }
         break;
      case SM1_B1_on: 
         if (A0 == 0) {
            SM1_State = SM1_B2_on;
            B1 = 0;
            
         }
         else if (A0 == 1) {
            SM1_State = SM1_B0_on;
            B1 = 0;
         }
         break;
      case SM1_init: 
         if (1) {
            SM1_State = SM1_B0_on;
         }
         break;
      case SM1_B2_on: 
         if (A0 == 0) {
            SM1_State = SM1_B3_on;
            B2 = 0;
         }
         else if (A0 == 1) {
            SM1_State = SM1_B1_on;
            B2 = 0;
         }
         break;
      case SM1_B3_on: 
         if (A0 == 0) {
            SM1_State = SM1_B4_on;
            B3 = 0;
         }
         else if (A0 == 1) {
            SM1_State = SM1_B2_on;
            B3 = 0;
         }
         break;
      case SM1_B4_on: 
         if (A0 == 0) {
            SM1_State = SM1_B5_on;
            B4 = 0;
         }
         else if (A0 == 1) {
            SM1_State = SM1_B3_on;
            B4 = 0;
         }
         break;
      case SM1_B5_on: 
         if (A0 == 0) {
            SM1_State = SM1_B6_on;
            B5 = 0;
         }
         else if (A0 == 1) {
            SM1_State = SM1_B4_on;
            B5 = 0;
         }
         break;
      case SM1_B6_on: 
         if (A0 == 0) {
            SM1_State = SM1_B7_on;
            B6 = 0;
         }
         else if (A0 == 1) {
            SM1_State = SM1_B5_on;
            B6 = 0;
         }
         break;
      case SM1_B7_on: 
         if (A0 == 0) {
            SM1_State = SM1_B0_on;
            B7 = 0;
         }
         else if (A0 == 1) {
            SM1_State = SM1_B6_on;
            B7 = 0;
         }
         break;
      default:
         SM1_State = SM1_init;
   } // Transitions

   switch(SM1_State) { // State actions
      case SM1_B0_on:
         B0 = 1;
         break;
      case SM1_B1_on:
         B1 = 1;
         break;
      case SM1_init:
         B0 = 0;
         B1 = 0;
         B2 = 0;
         B3 = 0;
         B4 = 0;
         B5 = 0;
         B6 = 0;
         B7 = 0;
         break;
      case SM1_B2_on:
         B2 = 1;
         break;
      case SM1_B3_on:
         B3 = 1;
         break;
      case SM1_B4_on:
         B4 = 1;
         break;
      case SM1_B5_on:
         B5 = 1;
         break;
      case SM1_B6_on:
         B6 = 1;
         break;
      case SM1_B7_on:
         B7 = 1;
         break;
      default: // ADD default behaviour below
      break;
   } // State actions

}

int main() {

   const unsigned int periodState_machine_1 = 1000; // 1000 ms default
   TimerSet(periodState_machine_1);
   TimerOn();
   
   SM1_State = -1; // Initial state
   B = 0; // Init outputs

   while(1) {
      TickFct_State_machine_1();
      while(!SM1_Clk);
      SM1_Clk = 0;
   } // while (1)
} // Main