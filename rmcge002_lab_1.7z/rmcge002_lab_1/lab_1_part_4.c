/*
This code was automatically generated using the Riverside-Irvine State machine Builder tool
Version 2.7 --- 10/3/2018 21:28:25 PST
*/
/*	Partner(s) Name & E-mail: NA
 *	Lab Section: 021
 *	Assignment: Lab #1  Exercise #4 
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

//I DID NOT HAVE A PARTNER SO I JUST MADE A GAME WHERE YOU HAVE TO MATCH THE CORRECT
//B PORT WITH THE INPUT 
//AND THERES A TIMER IF YOU TAKE TOO LONG TO MATCH IT RESETS THE GAME
//TWO STATE MACHINES ONE FOR DISPLAY AND "COLLISION" HANDLING
//THE OTHER FOR TAKING IN CONTINOUS INPUT AT A LOWER PERIOD RATE TO PREVENT INPUTS
//NOT BEING RECIENVED 
//ALSO THERES A WIN MESSAGE AND A LOSE MESSAGE AFTER BOTH THE GAME RESETS



#include "rims.h"

/*This code will be shared between state machines.*/

unsigned char input;
unsigned char time_cntdwn;
unsigned char time_message = 0;

unsigned char num[5] = {0x14,0x45,0x62,0x78,0x11};
signed char x = 0;
typedef struct task {
   int state;
   unsigned long period;
   unsigned long elapsedTime;
   int (*TickFct)(int);
} task;

task tasks[2];

const unsigned char tasksNum = 2;
const unsigned long periodDisplay = 1000;
const unsigned long periodInput = 100;

const unsigned long tasksPeriodGCD = 100;

int TickFct_Display(int state);
int TickFct_Input(int state);

unsigned char processingRdyTasks = 0;
void TimerISR() {
   unsigned char i;
   if (processingRdyTasks) {
      printf("Period too short to complete tasks\n");
   }
   processingRdyTasks = 1;
   for (i = 0; i < tasksNum; ++i) { // Heart of scheduler code
      if ( tasks[i].elapsedTime >= tasks[i].period ) { // Ready
         tasks[i].state = tasks[i].TickFct(tasks[i].state);
         tasks[i].elapsedTime = 0;
      }
      tasks[i].elapsedTime += tasksPeriodGCD;
   }
   processingRdyTasks = 0;
}
int main() {
   // Priority assigned to lower position tasks in array
   unsigned char i=0;
   tasks[i].state = -1;
   tasks[i].period = periodDisplay;
   tasks[i].elapsedTime = tasks[i].period;
   tasks[i].TickFct = &TickFct_Display;

   ++i;
   tasks[i].state = -1;
   tasks[i].period = periodInput;
   tasks[i].elapsedTime = tasks[i].period;
   tasks[i].TickFct = &TickFct_Input;

   ++i;
   TimerSet(tasksPeriodGCD);
   TimerOn();
   
   while(1) { Sleep(); }

   return 0;
}

enum SM1_States { SM1_init, SM1_Display_num, SM1_Wait_until_right_input, SM1_right_input, SM1_s5 } SM1_State;
int TickFct_Display(int state) {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/
   switch(state) { // Transitions
      case -1:
         state = SM1_init;
         break;
      case SM1_init:
         if (1) {
            state = SM1_Display_num;
            x = 0;
         }
         break;
      case SM1_Display_num:
         if (1) {
            state = SM1_Wait_until_right_input;
            time_cntdwn = 0;
         }
         break;
      case SM1_Wait_until_right_input:
         if (input == B && 
time_cntdwn< 8) {
            state = SM1_right_input;
            time_message = 0;
         }
         else if (input != B && time_cntdwn < 8) {
            state = SM1_Wait_until_right_input;
         }
         else if (time_cntdwn>=8) {
            state = SM1_s5;
            time_message = 0;
         }
         break;
      case SM1_right_input:
         if (time_message< 3) {
            state = SM1_right_input;
         }
         else if (time_message >=3) {
            state = SM1_Display_num;
            if (x >= 4){
 
 x = 0;
}

else{
 x++;
}
         }
         break;
      case SM1_s5:
         if (time_message < 3) {
            state = SM1_s5;
         }
         else if (time_message>=3
) {
            state = SM1_Display_num;
            x = 0;
         }
         break;
      default:
         state = -1;
      } // Transitions

   switch(state) { // State actions
      case SM1_init:
         break;
      case SM1_Display_num:
         B = num[x];
         break;
      case SM1_Wait_until_right_input:
         time_cntdwn ++;
         break;
      case SM1_right_input:
         if (x == 4){
          B = 0xFF;
          x = -1;
         }
         else{
         B = 0xF3;
         }
         time_message ++;
         break;
      case SM1_s5:
         B = 0x3F;
         time_message ++;
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
   SM1_State = state;
   return state;
}


enum SM2_States { SM2_init, SM2_input } SM2_State;
int TickFct_Input(int state) {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/
   switch(state) { // Transitions
      case -1:
         state = SM2_init;
         break;
      case SM2_init:
         if (1) {
            state = SM2_input;
         }
         break;
      case SM2_input:
         if (1) {
            state = SM2_input;
         }
         break;
      default:
         state = -1;
      } // Transitions

   switch(state) { // State actions
      case SM2_init:
         break;
      case SM2_input:
         input = A;
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
   SM2_State = state;
   return state;
}

