/*
This code was automatically generated using the Riverside-Irvine State machine Builder tool
Version 2.7 --- 10/3/2018 20:11:48 PST
*/

#include "rims.h"

/*Define user variables and functions for this state machine here.*/
/*Define user variables and functions for this state machine here.*/
unsigned char array [10] = {0xFF,0x00,0xFF,0x00,0xFF,0x08,
0x08,0x12,0x12,0x03};
unsigned char x = 0;
unsigned char SM1_Clk;
void TimerISR() {
   SM1_Clk = 1;
}

enum SM1_States { SM1_init, SM1_song } SM1_State;

TickFct_State_machine_1() {
   switch(SM1_State) { // Transitions
      case -1:
         SM1_State = SM1_init;
         break;
         case SM1_init: 
         if (1) {
            SM1_State = SM1_song;
         }
         break;
      case SM1_song: 
         if (1) {
            SM1_State = SM1_song;
         }
         break;
      default:
         SM1_State = SM1_init;
   } // Transitions

   switch(SM1_State) { // State actions
      case SM1_init:
         break;
      case SM1_song:
         B = array[x];
         x += 1;
         
         if (x >9 ){
         x = 0;
         }
         break;
      default: // ADD default behaviour below
      break;
   } // State actions

}

int main() {

   const unsigned int periodState_machine_1 = 100;
   TimerSet(periodState_machine_1);
   TimerOn();
   
   SM1_State = -1; // Initial state
   B = 0; // Init outputs

   while(1) {
      TickFct_State_machine_1();
      while(!SM1_Clk);
      SM1_Clk = 0;
   } // while (1)
} // Main