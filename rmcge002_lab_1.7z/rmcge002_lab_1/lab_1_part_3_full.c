/*
This code was automatically generated using the Riverside-Irvine State machine Builder tool
Version 2.7 --- 10/3/2018 20:18:15 PST
*/

/*	Partner(s) Name & E-mail: NA
 *	Lab Section: 021
 *	Assignment: Lab #1  Exercise #3 
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


#include "rims.h"

/*This code will be shared between state machines.*/

unsigned char input;
unsigned char multiple;
unsigned char limit = 255;
unsigned char sum = 0;
unsigned char TimerFlag = 0;
void TimerISR() {
   TimerFlag = 1;
}


enum Input_States { Input_init, Input_wait, Input_Check_A } Input_State;

TickFct_Input() {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/


   switch(Input_State) { // Transitions
      case -1:
         Input_State = Input_init;
         break;
      case Input_init:
         if (1) {
            Input_State = Input_wait;
         }
         break;
      case Input_wait:
         if (1) {
            Input_State = Input_Check_A;
         }
         break;
      case Input_Check_A:
         if (input == A) {
            Input_State = Input_Check_A;
         }
         else if (input != A) {
            Input_State = Input_wait;
         }
         break;
      default:
         Input_State = Input_init;
      } // Transitions

   switch(Input_State) { // State actions
      case Input_init:
         input = 0;
         break;
      case Input_wait:
         input = A;
         B = 0;
         break;
      case Input_Check_A:
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
}

enum Display_States { Display_init, Display_display, Display_Reset_mult } Display_State;

TickFct_Display() {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/
   switch(Display_State) { // Transitions
      case -1:
         Display_State = Display_init;
         break;
      case Display_init:
         if (1) {
            Display_State = Display_Reset_mult;
         }
         break;
      case Display_display:
         if (multiple == input) {
            Display_State = Display_display;
         }
         else if (multiple !=input) {
            Display_State = Display_Reset_mult;
         }
         break;
      case Display_Reset_mult:
         if (1) {
            Display_State = Display_display;
            multiple = input;
sum = 0;
         }
         break;
      default:
         Display_State = Display_init;
      } // Transitions

   switch(Display_State) { // State actions
      case Display_init:
         break;
      case Display_display:
         sum += multiple;
         if (sum > limit){
         sum = 0;
         }
         
         B = sum;
         break;
      case Display_Reset_mult:
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
}
int main() {
   B = 0; //Init outputs
   TimerSet(1000);
   TimerOn();
   Input_State = -1;
   Display_State = -1;
   while(1) {
      TickFct_Input();
      TickFct_Display();
      while (!TimerFlag);
      TimerFlag = 0;
   }
}