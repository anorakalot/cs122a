/*
This code was automatically generated using the Riverside-Irvine State machine Builder tool
Version 2.7 --- 10/3/2018 20:5:36 PST
*/

#include "rims.h"

/*This code will be shared between state machines.*/
unsigned char Sequence = 0;
unsigned char Pattern = 0;
unsigned char Song = 0;

unsigned char array [10] = {0x01,0x02,0xF0,0x0F,0xF0,0x0F,
0xF0,0x0F,0x40,0x80};
signed char x = 0;

unsigned char second_array [10] = {0xFF,0x00,0xFF,0x00,0xFF,0x08,
0x08,0x12,0x12,0x03};
unsigned char x_two = 0;


unsigned char timer = 0;
unsigned char turn_on_which = 0;
typedef struct task {
   int state;
   unsigned long period;
   unsigned long elapsedTime;
   int (*TickFct)(int);
} task;

task tasks[4];

const unsigned char tasksNum = 4;
const unsigned long periodSequence = 1000;
const unsigned long periodPattern = 1000;
const unsigned long periodSong = 100;
const unsigned long periodDecide_sm = 500;

const unsigned long tasksPeriodGCD = 100;

int TickFct_Sequence(int state);
int TickFct_Pattern(int state);
int TickFct_Song(int state);
int TickFct_Decide_sm(int state);

unsigned char processingRdyTasks = 0;
void TimerISR() {
   unsigned char i;
   if (processingRdyTasks) {
      printf("Period too short to complete tasks\n");
   }
   processingRdyTasks = 1;
   for (i = 0; i < tasksNum; ++i) { // Heart of scheduler code
      if ( tasks[i].elapsedTime >= tasks[i].period ) { // Ready
         tasks[i].state = tasks[i].TickFct(tasks[i].state);
         tasks[i].elapsedTime = 0;
      }
      tasks[i].elapsedTime += tasksPeriodGCD;
   }
   processingRdyTasks = 0;
}
int main() {
   // Priority assigned to lower position tasks in array
   unsigned char i=0;
   tasks[i].state = -1;
   tasks[i].period = periodSequence;
   tasks[i].elapsedTime = tasks[i].period;
   tasks[i].TickFct = &TickFct_Sequence;

   ++i;
   tasks[i].state = -1;
   tasks[i].period = periodPattern;
   tasks[i].elapsedTime = tasks[i].period;
   tasks[i].TickFct = &TickFct_Pattern;

   ++i;
   tasks[i].state = -1;
   tasks[i].period = periodSong;
   tasks[i].elapsedTime = tasks[i].period;
   tasks[i].TickFct = &TickFct_Song;

   ++i;
   tasks[i].state = -1;
   tasks[i].period = periodDecide_sm;
   tasks[i].elapsedTime = tasks[i].period;
   tasks[i].TickFct = &TickFct_Decide_sm;

   ++i;
   TimerSet(tasksPeriodGCD);
   TimerOn();
   
   while(1) { Sleep(); }

   return 0;
}

enum SM1_States { SM1_B0_on, SM1_B1_on, SM1_init, SM1_B2_on, SM1_B3_on, SM1_B4_on, SM1_B5_on, SM1_B6_on, SM1_B7_on, SM1_wait } SM1_State;
int TickFct_Sequence(int state) {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/
   switch(state) { // Transitions
      case -1:
         state = SM1_init;
         break;
      case SM1_B0_on:
         if (A0 == 0 && Sequence == 1) {
            state = SM1_B1_on;
            B0 = 0;

         }
         else if (A0 == 1&& Sequence == 1) {
            state = SM1_B7_on;
            B0 = 0;
         }
         else if (Sequence ==0) {
            state = SM1_wait;
         }
         break;
      case SM1_B1_on:
         if (A0 == 0 &&  Sequence == 1) {
            state = SM1_B2_on;
            B1 = 0;

         }
         else if (A0 == 1 && Sequence == 1) {
            state = SM1_B0_on;
            B1 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_init:
         if (1) {
            state = SM1_wait;
         }
         break;
      case SM1_B2_on:
         if (A0 == 0&& Sequence == 1) {
            state = SM1_B3_on;
            B2 = 0;
         }
         else if (A0 == 1&& Sequence == 1) {
            state = SM1_B1_on;
            B2 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_B3_on:
         if (A0 == 0&& Sequence == 1) {
            state = SM1_B4_on;
            B3 = 0;
         }
         else if (A0 ==1 && Sequence == 1) {
            state = SM1_B2_on;
            B3 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_B4_on:
         if (A0 == 0&& Sequence == 1) {
            state = SM1_B5_on;
            B4 = 0;
         }
         else if (A0 == 1&& Sequence == 1) {
            state = SM1_B3_on;
            B4 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_B5_on:
         if (A0 == 0&& Sequence == 1) {
            state = SM1_B6_on;
            B5 = 0;
         }
         else if (A0 == 1&& Sequence == 1) {
            state = SM1_B4_on;
            B5 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_B6_on:
         if (A0 == 0&& Sequence == 1) {
            state = SM1_B7_on;
            B6 = 0;
         }
         else if (A0 == 1&& Sequence == 1) {
            state = SM1_B5_on;
            B6 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_B7_on:
         if (A0 == 0&& Sequence == 1) {
            state = SM1_B0_on;
            B7 = 0;
         }
         else if (A0 == 1&& Sequence == 1) {
            state = SM1_B6_on;
            B7 = 0;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      case SM1_wait:
         if (Sequence == 1) {
            state = SM1_B0_on;
         }
         else if (Sequence == 0) {
            state = SM1_wait;
         }
         break;
      default:
         state = -1;
      } // Transitions

   switch(state) { // State actions
      case SM1_B0_on:
         B0 = 1;
         break;
      case SM1_B1_on:
         B1 = 1;
         break;
      case SM1_init:
         B0 = 0;
         B1 = 0;
         B2 = 0;
         B3 = 0;
         B4 = 0;
         B5 = 0;
         B6 = 0;
         B7 = 0;
         break;
      case SM1_B2_on:
         B2 = 1;
         break;
      case SM1_B3_on:
         B3 = 1;
         break;
      case SM1_B4_on:
         B4 = 1;
         break;
      case SM1_B5_on:
         B5 = 1;
         break;
      case SM1_B6_on:
         B6 = 1;
         break;
      case SM1_B7_on:
         B7 = 1;
         break;
      case SM1_wait:
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
   SM1_State = state;
   return state;
}


enum SM2_States { SM2_init, SM2_inc, SM2_wait } SM2_State;
int TickFct_Pattern(int state) {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/

   switch(state) { // Transitions
      case -1:
         state = SM2_init;
         break;
      case SM2_init:
         if (1) {
            state = SM2_wait;
         }
         break;
      case SM2_inc:
         if (Pattern == 1) {
            state = SM2_inc;
         }
         else if (Pattern == 0) {
            state = SM2_wait;
         }
         break;
      case SM2_wait:
         if (Pattern == 1) {
            state = SM2_inc;
            x = 0;
         }
         else if (Pattern == 0) {
            state = SM2_wait;
         }
         break;
      default:
         state = -1;
      } // Transitions

   switch(state) { // State actions
      case SM2_init:
         break;
      case SM2_inc:
         B = array[x];
         if (A0 ==0){
         x += 1;
         }
         else if (A0 == 1){
         x -= 1;
         }
         
         if (x == 0 && A0 == 1){
         x = 9;
         }
         
         if (x >9 && A1 == 0){
         x = 0;
         }
         
         break;
      case SM2_wait:
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
   SM2_State = state;
   return state;
}


enum SM5_States { SM5_init, SM5_song, SM5_wait } SM5_State;
int TickFct_Song(int state) {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/

   switch(state) { // Transitions
      case -1:
         state = SM5_init;
         break;
      case SM5_init:
         if (1) {
            state = SM5_wait;
         }
         break;
      case SM5_song:
         if (Song ==1) {
            state = SM5_song;
         }
         else if (Song == 0) {
            state = SM5_wait;
         }
         break;
      case SM5_wait:
         if (Song == 1) {
            state = SM5_song;
            x_two = 0;
         }
         else if (Song == 0) {
            state = SM5_wait;
         }
         break;
      default:
         state = -1;
      } // Transitions

   switch(state) { // State actions
      case SM5_init:
         break;
      case SM5_song:
         B = second_array[x_two];
         x_two+=1;
         
         if (x_two > 9){
         x_two = 0;
         }
         break;
      case SM5_wait:
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
   SM5_State = state;
   return state;
}


enum SM4_States { SM4_init, SM4_s2, SM4_s3, SM4_wait_for_input, SM4_s5 } SM4_State;
int TickFct_Decide_sm(int state) {
   /*VARIABLES MUST BE DECLARED STATIC*/
/*e.g., static int x = 0;*/
/*Define user variables for this state machine here. No functions; make them global.*/

   switch(state) { // Transitions
      case -1:
         state = SM4_init;
         break;
      case SM4_init:
         if (1) {
            state = SM4_wait_for_input;
         }
         break;
      case SM4_s2:
         if (timer <10) {
            state = SM4_s2;
         }
         else if (timer >=10) {
            state = SM4_s3;
            turn_on_which ++;
         }
         break;
      case SM4_s3:
         if (turn_on_which <=3) {
            state = SM4_s2;
            B = 0;
         }
         else if (turn_on_which > 3) {
            state = SM4_wait_for_input;
            Sequence = 0;
Pattern = 0;
Song = 0;
         }
         break;
      case SM4_wait_for_input:
         if (A6 == 1 && A7 == 1) {
            state = SM4_s5;
            Sequence = 0;
Pattern = 0;
Song = 0;
         }
         else if (A6 == 0 && A7 == 0) {
            state = SM4_s2;
            turn_on_which = 1;
B = 0;
         }
         else if ((A6 == 0 && A7 == 1) || (A6 ==1 && A7 ==0)) {
            state = SM4_wait_for_input;
         }
         break;
      case SM4_s5:
         break;
      default:
         state = -1;
      } // Transitions

   switch(state) { // State actions
      case SM4_init:
         Sequence = 0;
         Pattern = 0;
         Song = 0;
         
         break;
      case SM4_s2:
         timer ++;
         if (turn_on_which == 1){
          Sequence = 1;
          Pattern = 0;
         Song = 0;
         }
         
         else if (turn_on_which == 2 ){
          Sequence = 0;
          Pattern = 1;
          Song = 0; 
         }
         else if (turn_on_which == 3){
          Sequence = 0;
          Pattern = 0;
          Song = 1; 
         }
         
         
         break;
      case SM4_s3:
         timer = 0;
         break;
      case SM4_wait_for_input:
         break;
      case SM4_s5:
         B = 0xFF;
         break;
      default: // ADD default behaviour below
         break;
   } // State actions
   SM4_State = state;
   return state;
}

