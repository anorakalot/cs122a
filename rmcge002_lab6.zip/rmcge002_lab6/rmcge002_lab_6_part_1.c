/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 6 Exercise # 1
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
  
 //Buttons are connected to PA0 and PA1. Output for PORTC is initially 7. 
 //Pressing PA0 increments PORTC once (stopping at 9). Pressing PA1 decrements PORTC once (stopping at 0).
 // If both buttons are depressed (even if not initially simultaneously), PORTC resets to 0.

#include <avr/io.h>
#include "io.c"

volatile unsigned char TimerFlag = 0; // TimerISR() sets this to 1. C programmer should clear to 0.
void TimerISR() {
	TimerFlag = 1;
}

// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}



enum states {Start,Init, Control, PA1_Press , PA0_Press, Reset,Add,Subtract} state;
	//inputs
unsigned char PORT_A_0;
unsigned char PORT_A_1;

unsigned long time_cnt = 0;
unsigned char cnt = 0x00;

void tick (){

	PORT_A_0 = ~PINA & 0x01;
	PORT_A_1 = ~PINA & 0x02;


	switch(state){//transitions
		
		case Start:
			state = Init;
			break;

		case Init:
			state = Control;
			break;

		case Control:
			if (PORT_A_0 == 0x01 && PORT_A_1 != 0x02){
				state = Add;
			}
			else if (PORT_A_0 != 0x01 && PORT_A_1 == 0x02){
				state = Subtract;
			}
			else if (PORT_A_0 == 0x01 && PORT_A_1 == 0x02){
				state = Reset;
			}

			else {
				state = Control;
			}
			break;

		case PA0_Press:
		
			if ( PORT_A_1 == 0x02 ){
				state = Reset;
			}

			else if (PORT_A_0 != 0x01){
				state = Control;
			}
			else if (PORT_A_0 == 0x01){
				state = PA0_Press;
			}
			else{
				state = PA0_Press;
			}
		
			break;

		case PA1_Press:
			if (PORT_A_0 == 0x01 ){
				state = Reset;
			}

			else if (PORT_A_1 == 0x02 ){
				state = PA1_Press;
			}

			else if (PORT_A_1 != 0x02 ){
				state = Control;
			}
			else{
				state = PA1_Press;
			}
			break;

		case Reset:
			if (PORT_A_0 != 0x01 && PORT_A_1 != 0x02){
				state = Control;
			}
			else{
				state = Reset;
			}
			break;
		case Add:
			state = PA0_Press;
			break;
		case Subtract:
			state = PA1_Press;
			break;

		default:
			state = Start;
			break;
	}

	switch(state){//actions
		case Start:
			break;
		case Init:
			LCD_init();
			cnt = 0x00;
			time_cnt = 0x00;
			LCD_ClearScreen();
			LCD_Cursor(1);
			LCD_WriteData(cnt + '0');
			break;
		case Reset:
			cnt = 0x00;
			//LCD_ClearScreen();
			LCD_Cursor(1);
			LCD_WriteData(cnt + '0');
			break;
		case Control:
			time_cnt = 0;
			break;
		case PA1_Press:
			time_cnt ++;
			if (cnt >= 0x01){
				cnt = (time_cnt%10 == 0)? cnt-1: cnt;	
			}
			
			//LCD_ClearScreen();
			LCD_Cursor(1);
			LCD_WriteData(cnt + '0');

			break;
		case PA0_Press:
			time_cnt ++;
			if (cnt <= 0x08){
				cnt = (time_cnt%10 == 0)? cnt+1: cnt;	
			}
			//LCD_ClearScreen();
			LCD_Cursor(1);
			LCD_WriteData(cnt + '0');


			break;
		case Add:
			if (cnt <= 0x08){
				cnt = cnt +1;
			}
			//LCD_ClearScreen();
			LCD_Cursor(1);
			LCD_WriteData(cnt + '0');

			break;
		case Subtract:
			if (cnt >= 0x01){
				cnt = cnt -1;
			}
			//LCD_ClearScreen();
			LCD_Cursor(1);
			LCD_WriteData(cnt + '0');

			break;
	}
	

}

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	
	DDRC = 0xFF; PORTC = 0x00; // LCD data lines
	DDRD = 0xFF; PORTD = 0x00; // LCD control lines
	
	TimerSet(100);
	TimerOn();
	state = Start;

	
	/* Replace with your application code */
	while (1)
	{
		tick();
		while (!TimerFlag);	// Wait 1 sec
		TimerFlag = 0;

	}
}
