/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 4 Exercise # 1
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>

enum states{Start,INIT, CONTROL, BUTTON_START_AGAIN,LED_BUTTON_PRESS,LED_1,LED_2,LED_3} state;

volatile unsigned char TimerFlag = 0; // TimerISR() sets this to 1. C programmer should clear to 0.
void TimerISR() {
	TimerFlag = 1;
}

// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

unsigned char x = 0;

void tick(){
unsigned char button = ~PINA &0x01;

	switch(state){ // transitions
		case Start:
			state = INIT;
			break;
		case INIT:
			state = CONTROL;
			break;
		case CONTROL:
			if (button == 0x01){
				state = BUTTON_START_AGAIN;
			}
			else if (button == 0x00){
				state = CONTROL;
			}
			break;
		case BUTTON_START_AGAIN:
			if (button == 0x01){
				state = BUTTON_START_AGAIN;
			}
			else if (button == 0x00){
				state = LED_1;
			}
			break;
		case LED_1:
			if (button == 0x01){
				state = LED_BUTTON_PRESS;
			}
			else if (button == 0x00){
				state = LED_2;
			}
			
			break;
		case LED_2:
			if (button == 0x01){
				state = LED_BUTTON_PRESS;
				
			}
			else if (button == 0x00){
				state = LED_3;
			}

			
			break;
		case LED_3:
			if (button == 0x01){
				state = LED_BUTTON_PRESS;
			}
			
			else if (button == 0x00){
				state = LED_1;
			}
			
			break;
		
		case LED_BUTTON_PRESS:
			if (button == 0x01){
				state = LED_BUTTON_PRESS;
			}
			else if (button == 0x00){
				state = CONTROL;
			}
			break;
		default:
			state = Start;
			break;


	}
	switch(state){ // output
		case Start:
			break;
		case INIT:
			x = 0;
			break;
		case CONTROL:
			if (x== 0){
				PORTC = 0x01;
			}
			else if (x ==1){
				PORTC = 0x02;
			}
			else{
				PORTC = 0x04;
			}
			break;
		case BUTTON_START_AGAIN:
			break;
		case LED_BUTTON_PRESS:
			if (x== 0){
				PORTC = 0x01;
			}
			else if (x ==1){
				PORTC = 0x02;
			}
			else{
				PORTC = 0x04;
			}
			break;

		case LED_1:
			PORTC = 0x01;
			x = 0;
			break;
		case LED_2:
			PORTC = 0x02;
			x=1;
			break;
		case LED_3:
			PORTC = 0x04;
			x =2;
			break;
	}
}
int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;
	DDRC = 0xFF; PORTC = 0x00;
	TimerSet(330);
	TimerOn();
	state = Start;
	while(1) {
		// User code (i.e. synchSM calls)
		tick();
		while (!TimerFlag);	// Wait 1 sec
		TimerFlag = 0;
		// Note: For the above a better style would use a synchSM with TickSM()
		// This example just illustrates the use of the ISR and flag
	}
}



