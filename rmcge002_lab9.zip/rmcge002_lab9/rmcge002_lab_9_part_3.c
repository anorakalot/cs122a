/*	Partner(s) Name & E-mail: Andres Sanchez
 *	Lab Section: B21
 *	Assignment: Lab # 9 Exercise # 3
 *	Exercise Description: [optional - include for your own benefit]
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#define tasksSize  1
#define arraySize 7

#define C4 261.63
#define D 293.66
#define E 329.63
#define F 349.23
#define G 392.00
#define A 440.00
#define B 493.88


double Sound_Array [arraySize]= {C4,B,D,A,E,G,F};
double Length_Array [arraySize] = {9,4,4,9,4,4,9};
unsigned char x = 0; 

unsigned long tasksPeriod = 100;

typedef struct Task {
	int state;						// Task�s current state
	unsigned long period;			// Task period
	unsigned long elapsedTime;	// Time elapsed since last task tick
	int (*TickFct)(int);				// Task tick function
} Task;

Task tasks[tasksSize];
void TimerISR(){
	unsigned char i;
	for (i = 0;i < tasksSize;++i) {
		if (tasks[i].elapsedTime >= tasks[i].period) {
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += tasksPeriod;
	}
}


// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;// bit3 = 0: CTC mode (clear timer on compare)
	// bit2bit1bit0=011: pre-scaler /64
	// 00001011: 0x0B
	// SO, 8 MHz clock or 8,000,000 /64 = 125,000 ticks/s
	// Thus, TCNT1 register will count at 125,000 ticks/s

	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	// We want a 1 ms tick. 0.001 s * 125,000 ticks/s = 125
	// So when TCNT1 register equals 125,
	// 1 ms has passed. Thus, we compare to 125.
	// AVR timer interrupt mask register
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	// TimerISR will be called every _avr_timer_cntcurr milliseconds

	//Enable global interrupts
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


// In our approach, the C programmer does not touch this ISR, but rather TimerISR()
ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}

// If different frequency, setup new frequency, else keep the same
void set_PWM(double frequency) {
	static double current_frequency;
	if (frequency != current_frequency) {
		if (!frequency) { TCCR0B &= 0x08; } //stops timer/counter
		else { TCCR0B |= 0x03; } // resumes/continues timer/counter		
		if (frequency < 0.954) { OCR0A = 0xFFFF; }        // prevent overflow
		else if (frequency > 31250) { OCR0A = 0x0000; }    // prevent underflow
		else { OCR0A = (short)(8000000 / (128 * frequency)) - 1; }    // set freq.
		TCNT0 = 0; // resets counter
		current_frequency = frequency;
	}
}
// Enable PWM functionality
void PWM_on() {
	TCCR0A = (1 << COM0A0 | 1 << WGM00);
	TCCR0B = (1 << WGM02) | (1 << CS01) | (1 << CS00);
	set_PWM(0);
}
// Enable PWM functionality
void PWM_off() {
	TCCR0A = 0x00;
	TCCR0B = 0x00;
}



enum states {START,INIT, CONTROL,SET_NOTE,SET_TIME,WAIT_FOR_BUTTON_OFF} state;
	//inputs
unsigned char PORT_A_0;
unsigned char PORT_A_1;
unsigned char PORT_A_2;

unsigned char toggle = 0x00;
unsigned long time_cnt = 0;

int tick (int state){

	PORT_A_0 = ~PINA & 0x02;


	switch(state){//transitions
		
		case START:
			state = INIT;
			break;

		case INIT:
			state = CONTROL;
			break;

		case CONTROL:
			
			if (PORT_A_0 == 0x02){
				x = 0;
				state = SET_NOTE;
			}
			
			else {
				state = CONTROL;
			}

			break;

		case SET_NOTE:
			state = SET_TIME;
			time_cnt = 0;
			break;
		case SET_TIME:
			
			if (x==6 && time_cnt >= Length_Array[x]){
				state = WAIT_FOR_BUTTON_OFF;
			}
			else if (time_cnt >= Length_Array[x]){
				state = SET_NOTE;
				x ++;
			}
			else{				
				state = SET_TIME;
			}
			break;
		case WAIT_FOR_BUTTON_OFF:	
			if (PORT_A_0 == 0x02){
				state = WAIT_FOR_BUTTON_OFF;
			}
			else{
				state = CONTROL;
			}
			break;

		default:
			state = START;
			break;
	}
	switch(state){//actions
		case START:
			break;
		case INIT:
			PWM_on();
			x= 0;
			break;
		case CONTROL:
			PORTB = 0x08;
			set_PWM(0);
			break;
		case SET_NOTE:
			set_PWM(Sound_Array[x]);
			//PORTB = 0x01;
			break;
		case SET_TIME:
			//PORTB = 0x02;
			time_cnt ++;
			break;
		case WAIT_FOR_BUTTON_OFF:
			set_PWM(0);
			//PORTB = 0x04;
			break;
	}
	return state;
}


int main(void){
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0xFF; PORTB = 0x00; //USED TO JUST BE PB3	
	//DDRB = 0xFF; PORTB = 0x00;
	DDRD = 0xFF; PORTD = 0x00;

	unsigned char x = 0;
	tasks[x].state = START;
	tasks[x].period = 100;
	tasks[x].elapsedTime = 0;
	tasks[x].TickFct = &tick;	

	TimerSet(tasksPeriod);
	TimerOn();
	

	//PWM_on();
	while (1)
	{ 
	//x= 6;

	//freq = Sound_Array[x]; 
	//set_PWM(freq);
	} 
	return 0;
}

